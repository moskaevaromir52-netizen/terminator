package com.rustcraft.common;

import com.rustcraft.net.NetworkHandler;
import com.rustcraft.net.SyncPacket;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.PacketDistributor;

public final class TerminatorData {
    /** 0 = зрение, 1 = память, 2 = сканер */
    public static final String[] NAMES = {"vision", "memory", "scanner"};
    public static final String[] TITLES = {"Зрение", "Память", "Сканер"};
    public static final String[] LEVELS = {"повреждён", "средний", "максимальный"};

    private static final String ACTIVE = "rc_term_active";
    private static final String[] KEYS = {"rc_term_vision", "rc_term_memory", "rc_term_scanner"};

    private TerminatorData() {}

    public static boolean isActive(Player p) {
        return p.getPersistentData().getBoolean(ACTIVE);
    }

    public static int getLevel(Player p, int sys) {
        return Math.max(0, Math.min(2, p.getPersistentData().getInt(KEYS[sys])));
    }

    public static void setActive(ServerPlayer p, boolean a) {
        p.getPersistentData().putBoolean(ACTIVE, a);
        if (!a) p.removeEffect(MobEffects.NIGHT_VISION);
        sync(p);
    }

    public static void setLevel(ServerPlayer p, int sys, int level) {
        p.getPersistentData().putInt(KEYS[sys], Math.max(0, Math.min(2, level)));
        if (sys == 0 && level != 2) p.removeEffect(MobEffects.NIGHT_VISION);
        sync(p);
    }

    public static void sync(ServerPlayer p) {
        NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                new SyncPacket(isActive(p), getLevel(p, 0), getLevel(p, 1), getLevel(p, 2)));
    }

    public static void copy(Player from, Player to) {
        CompoundTag src = from.getPersistentData();
        CompoundTag dst = to.getPersistentData();
        dst.putBoolean(ACTIVE, src.getBoolean(ACTIVE));
        for (String k : KEYS) dst.putInt(k, src.getInt(k));
    }
}
