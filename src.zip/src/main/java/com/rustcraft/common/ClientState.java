package com.rustcraft.common;

/** Состояние игрока, синхронизированное с сервера (только данные, без клиентских классов). */
public final class ClientState {
    public static volatile boolean active = false;
    public static volatile int vision = 0;
    public static volatile int memory = 0;
    public static volatile int scanner = 0;

    private ClientState() {}

    public static void reset() {
        active = false;
        vision = 0;
        memory = 0;
        scanner = 0;
    }
}
