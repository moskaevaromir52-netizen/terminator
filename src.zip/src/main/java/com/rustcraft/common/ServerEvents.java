package com.rustcraft.common;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.rustcraft.RustCraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = RustCraft.MODID)
public class ServerEvents {

    // ---------- Команды (кнопки в чате отправляют именно их) ----------
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("terminator");
        root.then(Commands.literal("toggle").executes(c -> toggle(c.getSource().getPlayerOrException())));

        LiteralArgumentBuilder<CommandSourceStack> cycle = Commands.literal("cycle");
        LiteralArgumentBuilder<CommandSourceStack> set = Commands.literal("set");
        for (int i = 0; i < 3; i++) {
            final int sys = i;
            cycle.then(Commands.literal(TerminatorData.NAMES[i])
                    .executes(c -> cycle(c.getSource().getPlayerOrException(), sys)));
            set.then(Commands.literal(TerminatorData.NAMES[i])
                    .then(Commands.argument("level", IntegerArgumentType.integer(0, 2))
                            .executes(c -> setLevel(c.getSource().getPlayerOrException(), sys,
                                    IntegerArgumentType.getInteger(c, "level")))));
        }
        root.then(cycle);
        root.then(set);
        e.getDispatcher().register(root);
    }

    private static int toggle(ServerPlayer p) {
        boolean now = !TerminatorData.isActive(p);
        TerminatorData.setActive(p, now);
        p.displayClientMessage(Component.literal(now
                ? "Система T-800 активирована."
                : "Вы снова человек."), true);
        return 1;
    }

    private static int cycle(ServerPlayer p, int sys) {
        if (!TerminatorData.isActive(p)) {
            p.displayClientMessage(Component.literal("Сначала станьте терминатором."), true);
            return 0;
        }
        int next = (TerminatorData.getLevel(p, sys) + 1) % 3;
        return setLevel(p, sys, next);
    }

    private static int setLevel(ServerPlayer p, int sys, int level) {
        if (!TerminatorData.isActive(p)) {
            p.displayClientMessage(Component.literal("Сначала станьте терминатором."), true);
            return 0;
        }
        TerminatorData.setLevel(p, sys, level);
        p.displayClientMessage(Component.literal(TerminatorData.TITLES[sys] + ": "
                + TerminatorData.LEVELS[level] + " (" + level + "/2)"), true);
        return 1;
    }

    // ---------- Синхронизация ----------
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) TerminatorData.sync(sp);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) TerminatorData.sync(sp);
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) TerminatorData.sync(sp);
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        TerminatorData.copy(e.getOriginal(), e.getEntity());
    }

    // ---------- Память + ночное зрение (раз в секунду) ----------
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) return;
        if (!(e.player instanceof ServerPlayer p)) return;
        if (p.tickCount % 20 != 0) return;
        if (!TerminatorData.isActive(p)) return;

        // Максимальное зрение = красное ночное видение
        if (TerminatorData.getLevel(p, 0) == 2) {
            p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, false));
        }

        // Сбои памяти
        int mem = TerminatorData.getLevel(p, 1);
        if (mem >= 2) return;
        RandomSource r = p.getRandom();
        if (mem == 0) {
            if (r.nextInt(10) == 0) swapItems(p, r);
            else if (r.nextInt(40) == 0) dropItem(p, r);
        } else {
            if (r.nextInt(40) == 0) swapItems(p, r);
        }
    }

    private static void swapItems(ServerPlayer p, RandomSource r) {
        Inventory inv = p.getInventory();
        int a = r.nextInt(36), b = r.nextInt(36);
        if (a == b) return;
        ItemStack sa = inv.getItem(a), sb = inv.getItem(b);
        if (sa.isEmpty() && sb.isEmpty()) return;
        inv.setItem(a, sb);
        inv.setItem(b, sa);
        p.displayClientMessage(Component.literal("Сбой памяти: предметы перемещены."), true);
    }

    private static void dropItem(ServerPlayer p, RandomSource r) {
        Inventory inv = p.getInventory();
        List<Integer> filled = new ArrayList<>();
        for (int i = 0; i < 36; i++) if (!inv.getItem(i).isEmpty()) filled.add(i);
        if (filled.isEmpty()) return;
        int slot = filled.get(r.nextInt(filled.size()));
        ItemStack stack = inv.getItem(slot).copy();
        inv.setItem(slot, ItemStack.EMPTY);
        p.drop(stack, false);
        p.displayClientMessage(Component.literal("Сбой памяти: предмет выброшен."), true);
    }
}
