package com.rustcraft.client;

import com.mojang.blaze3d.shaders.FogShape;
import com.rustcraft.RustCraft;
import com.rustcraft.common.ClientState;
import com.rustcraft.common.TerminatorData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Mod.EventBusSubscriber(modid = RustCraft.MODID, value = Dist.CLIENT)
public class ClientEvents {

    // Параметры сканера по уровням: 0 = плохой, 1 = средний, 2 = максимальный
    private static final int[] LINE_INTERVAL = {100, 60, 40};   // белая полоса (тики)
    private static final int[] HL_INTERVAL   = {100, 60, 20};   // подсветка игроков (тики)
    private static final int[] HL_DURATION   = {40, 40, 30};    // длительность подсветки (тики)
    private static final double[] RADIUS     = {16, 32, 48};    // радиус сканирования
    private static final int LINE_SWEEP_TICKS = 20;

    private static int tick = 0;
    private static int lineStart = -1000;
    private static boolean shaderOn = false;
    private static LocalPlayer lastPlayer = null;
    private static final Map<Integer, Integer> highlighted = new HashMap<>();

    private static Button toggleBtn;
    private static final Button[] sysBtns = new Button[3];

    private static void send(String cmd) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.connection.sendCommand(cmd);
    }

    // ---------- Кнопки в чате ----------
    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post e) {
        if (!(e.getScreen() instanceof ChatScreen)) return;
        int w = e.getScreen().width;
        int x = w - 154;

        toggleBtn = Button.builder(Component.literal("Стать терминатором"), b -> send("terminator toggle"))
                .bounds(x, 4, 150, 20).build();
        e.addListener(toggleBtn);

        for (int i = 0; i < 3; i++) {
            final String name = TerminatorData.NAMES[i];
            sysBtns[i] = Button.builder(Component.literal(TerminatorData.TITLES[i]),
                            b -> send("terminator cycle " + name))
                    .bounds(x, 28 + i * 22, 150, 20).build();
            e.addListener(sysBtns[i]);
        }
        refreshButtons();
    }

    private static void refreshButtons() {
        if (toggleBtn == null) return;
        boolean a = ClientState.active;
        toggleBtn.setMessage(Component.literal(a ? "Стать человеком" : "Стать терминатором"));
        int[] lv = {ClientState.vision, ClientState.memory, ClientState.scanner};
        for (int i = 0; i < 3; i++) {
            if (sysBtns[i] == null) continue;
            sysBtns[i].visible = a;
            sysBtns[i].active = a;
            sysBtns[i].setMessage(Component.literal(TerminatorData.TITLES[i] + ": " + lv[i] + "/2 ("
                    + TerminatorData.LEVELS[lv[i]] + ")"));
        }
    }

    // ---------- Клиентский тик: шейдер, сканер ----------
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();

        if (mc.screen instanceof ChatScreen) refreshButtons();

        if (mc.player == null || mc.level == null) {
            shaderOn = false;
            highlighted.clear();
            lastPlayer = null;
            return;
        }
        if (mc.player != lastPlayer) { // новый игрок (респавн / смена измерения): эффект сбрасывается
            lastPlayer = mc.player;
            shaderOn = false;
            highlighted.clear();
        }
        tick++;

        boolean active = ClientState.active;

        // Чёрно-белое зрение (только при повреждённом слоте зрения)
        boolean wantMono = active && ClientState.vision == 0;
        if (wantMono && !shaderOn) {
            mc.gameRenderer.loadEffect(new ResourceLocation("shaders/post/desaturate.json"));
            shaderOn = true;
        } else if (!wantMono && shaderOn) {
            mc.gameRenderer.shutdownEffect();
            shaderOn = false;
        }

        // Сканер
        if (active) {
            int lvl = ClientState.scanner;
            if (tick % LINE_INTERVAL[lvl] == 0) lineStart = tick;
            if (tick % HL_INTERVAL[lvl] == 0) {
                double r2 = RADIUS[lvl] * RADIUS[lvl];
                for (AbstractClientPlayer p : mc.level.players()) {
                    if (p == mc.player) continue;
                    if (mc.player.distanceToSqr(p) <= r2) {
                        highlighted.put(p.getId(), tick + HL_DURATION[lvl]);
                    }
                }
            }
        } else if (!highlighted.isEmpty()) {
            for (int id : highlighted.keySet()) setGlow(mc, id, false);
            highlighted.clear();
        }

        Iterator<Map.Entry<Integer, Integer>> it = highlighted.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Integer> en = it.next();
            if (en.getValue() <= tick) {
                setGlow(mc, en.getKey(), false);
                it.remove();
            } else {
                setGlow(mc, en.getKey(), true);
            }
        }
    }

    /** Подсветка выставляется только на клиенте — другие игроки её не видят. */
    private static void setGlow(Minecraft mc, int id, boolean glow) {
        if (mc.level == null) return;
        Entity en = mc.level.getEntity(id);
        if (en != null) en.setGlowingTag(glow);
    }

    // ---------- Туман: дальше 6 блоков ничего не видно ----------
    @SubscribeEvent
    public static void onFog(ViewportEvent.RenderFog e) {
        if (!ClientState.active || ClientState.vision >= 2) return;
        float dist = ClientState.vision == 0 ? 6.0f : 24.0f;
        e.setNearPlaneDistance(0.0f);
        e.setFarPlaneDistance(dist);
        e.setFogShape(FogShape.SPHERE);
        e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor e) {
        if (!ClientState.active || ClientState.vision >= 2) return;
        e.setRed(0.0f);
        e.setGreen(0.0f);
        e.setBlue(0.0f);
    }

    // ---------- Красный оверлей ночного зрения ----------
    @SubscribeEvent
    public static void onGuiPre(RenderGuiEvent.Pre e) {
        if (!ClientState.active || ClientState.vision < 2) return;
        GuiGraphics g = e.getGuiGraphics();
        g.fill(0, 0, e.getWindow().getGuiScaledWidth(), e.getWindow().getGuiScaledHeight(), 0x38FF0000);
    }

    // ---------- Белая полоса сканера ----------
    @SubscribeEvent
    public static void onGuiPost(RenderGuiEvent.Post e) {
        if (!ClientState.active) return;
        float age = (tick - lineStart) + e.getPartialTick();
        if (age < 0 || age >= LINE_SWEEP_TICKS) return;
        int w = e.getWindow().getGuiScaledWidth();
        int h = e.getWindow().getGuiScaledHeight();
        int y = (int) (age / LINE_SWEEP_TICKS * h);
        GuiGraphics g = e.getGuiGraphics();
        g.fill(0, y - 10, w, y - 5, 0x18FFFFFF);
        g.fill(0, y - 5, w, y - 2, 0x40FFFFFF);
        g.fill(0, y - 2, w, y + 2, 0xFFFFFFFF);
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        ClientState.reset();
        highlighted.clear();
        shaderOn = false;
    }
}
