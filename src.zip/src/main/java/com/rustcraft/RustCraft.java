package com.rustcraft;

import com.rustcraft.net.NetworkHandler;
import net.minecraftforge.fml.common.Mod;

@Mod(RustCraft.MODID)
public class RustCraft {
    public static final String MODID = "rustcraft";

    public RustCraft() {
        NetworkHandler.register();
    }
}
