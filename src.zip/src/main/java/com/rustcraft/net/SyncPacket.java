package com.rustcraft.net;

import com.rustcraft.common.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SyncPacket {
    public final boolean active;
    public final int vision, memory, scanner;

    public SyncPacket(boolean active, int vision, int memory, int scanner) {
        this.active = active;
        this.vision = vision;
        this.memory = memory;
        this.scanner = scanner;
    }

    public static void encode(SyncPacket m, FriendlyByteBuf b) {
        b.writeBoolean(m.active);
        b.writeByte(m.vision);
        b.writeByte(m.memory);
        b.writeByte(m.scanner);
    }

    public static SyncPacket decode(FriendlyByteBuf b) {
        return new SyncPacket(b.readBoolean(), b.readByte(), b.readByte(), b.readByte());
    }

    public static void handle(SyncPacket m, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> {
            ClientState.active = m.active;
            ClientState.vision = m.vision;
            ClientState.memory = m.memory;
            ClientState.scanner = m.scanner;
        });
        ctx.setPacketHandled(true);
    }
}
